package com.example.a3dtwistedpairofwires

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector

class MyGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private val renderer: MyGLRenderer
    private val scaleDetector = ScaleGestureDetector(context, ScaleListener())
    private var previousX = 0f
    private var previousY = 0f

    init {
        setEGLContextClientVersion(2)
        renderer = MyGLRenderer()
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        if (!scaleDetector.isInProgress && event.pointerCount == 1) {
            val x = event.x
            val y = event.y
            if (event.action == MotionEvent.ACTION_MOVE) {
                val dx = x - previousX
                val dy = y - previousY
                renderer.angleX += dy * 0.5f
                renderer.angleY += dx * 0.5f
                requestRender()
            }
            previousX = x
            previousY = y
        }

        return true
    }

    inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            renderer.zoom *= detector.scaleFactor
            renderer.zoom = renderer.zoom.coerceIn(2f, 20f)
            requestRender()
            return true
        }
    }
}
