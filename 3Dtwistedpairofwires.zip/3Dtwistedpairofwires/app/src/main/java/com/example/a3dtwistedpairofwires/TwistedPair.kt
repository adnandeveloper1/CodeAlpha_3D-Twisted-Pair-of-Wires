package com.example.a3dtwistedpairofwires

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

class TwistedPair {
    private val vertexBuffer: FloatBuffer
    private val vertexCount: Int
    private val program: Int

    init {
        val vertices = mutableListOf<Float>()
        val turns = 10
        val segments = 100
        val radius = 0.2f
        val height = 4f

        for (i in 0..segments) {
            val t = i.toFloat() / segments
            val angle = 2 * Math.PI * turns * t
            val y = height * t - height / 2

            val x1 = (radius * cos(angle)).toFloat()
            val z1 = (radius * sin(angle)).toFloat()

            val x2 = (radius * cos(angle + Math.PI)).toFloat()
            val z2 = (radius * sin(angle + Math.PI)).toFloat()

            vertices.addAll(listOf(x1, y, z1)) // Red wire
            vertices.addAll(listOf(x2, y, z2)) // Blue wire
        }

        vertexCount = vertices.size / 3
        vertexBuffer = ByteBuffer.allocateDirect(vertices.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        vertexBuffer.put(vertices.toFloatArray())
        vertexBuffer.position(0)

        val vertexShaderCode = """
            uniform mat4 uMVPMatrix;
            attribute vec4 vPosition;
            void main() {
                gl_Position = uMVPMatrix * vPosition;
            }
        """

        val fragmentShaderCode = """
            precision mediump float;
            uniform vec4 vColor;
            void main() {
                gl_FragColor = vColor;
            }
        """

        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)

        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
        }
    }

    fun draw(mvpMatrix: FloatArray) {
        GLES20.glUseProgram(program)

        val positionHandle = GLES20.glGetAttribLocation(program, "vPosition")
        val colorHandle = GLES20.glGetUniformLocation(program, "vColor")
        val mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")

        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        // Draw red wire
        GLES20.glUniform4fv(colorHandle, 1, floatArrayOf(1f, 0f, 0f, 1f), 0)
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, vertexCount / 2)

        // Draw blue wire
        GLES20.glUniform4fv(colorHandle, 1, floatArrayOf(0f, 0f, 1f, 1f), 0)
        GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, vertexCount / 2, vertexCount / 2)

        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun loadShader(type: Int, code: String): Int {
        return GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, code)
            GLES20.glCompileShader(it)
        }
    }
}
